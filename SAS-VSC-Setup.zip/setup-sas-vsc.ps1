[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ServerIp,

    [string]$CertificateSha256 = ""
)

$ErrorActionPreference = "Stop"
$siteName = "sas-vsc.auto"
$siteUrl = "https://$siteName/"

$parsedAddress = $null
if (-not [System.Net.IPAddress]::TryParse($ServerIp, [ref]$parsedAddress) -or
    $parsedAddress.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
    throw "ServerIp must be an IPv4 address, such as 192.168.1.50."
}
$ServerIp = $parsedAddress.ToString()

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
$isAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdministrator) {
    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`"",
        "-ServerIp", $ServerIp
    )
    if ($CertificateSha256) {
        $arguments += @("-CertificateSha256", $CertificateSha256)
    }
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $arguments
    exit
}

$hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$backupPath = "$hostsPath.sas-vsc.backup"
Copy-Item -LiteralPath $hostsPath -Destination $backupPath -Force

$updatedLines = foreach ($line in Get-Content -LiteralPath $hostsPath) {
    $hostPart = ($line -split "#", 2)[0]
    $fields = @($hostPart -split "\s+" | Where-Object { $_ })
    if ($fields -notcontains $siteName) {
        $line
    }
}
$updatedLines += "$ServerIp`t$siteName"
Set-Content -LiteralPath $hostsPath -Value $updatedLines -Encoding ASCII
Clear-DnsClientCache

$temporaryCertificate = Join-Path ([System.IO.Path]::GetTempPath()) "sas-vsc-caddy-root.crt"
try {
    & curl.exe --fail --silent --show-error --insecure `
        --resolve "${siteName}:443:$ServerIp" `
        "${siteUrl}caddy-local-root.crt" `
        --output $temporaryCertificate
    if ($LASTEXITCODE -ne 0) {
        throw "Could not download Caddy's public CA certificate from $ServerIp."
    }

    $actualFingerprint = (Get-FileHash -LiteralPath $temporaryCertificate -Algorithm SHA256).Hash.ToUpperInvariant()
    $expectedFingerprint = ($CertificateSha256 -replace "[^0-9A-Fa-f]", "").ToUpperInvariant()
    if ($expectedFingerprint -and $actualFingerprint -ne $expectedFingerprint) {
        throw "Certificate fingerprint mismatch. Expected $expectedFingerprint but downloaded $actualFingerprint."
    }

    $certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($temporaryCertificate)
    try {
        if (-not $certificate.Subject -or $certificate.NotAfter -le (Get-Date)) {
            throw "The downloaded CA certificate is invalid or expired."
        }
    }
    finally {
        $certificate.Dispose()
    }

    Import-Certificate -FilePath $temporaryCertificate -CertStoreLocation "Cert:\LocalMachine\Root" | Out-Null
}
finally {
    Remove-Item -LiteralPath $temporaryCertificate -Force -ErrorAction SilentlyContinue
}

$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktopPath "Above and Beyond.url"
@"
[InternetShortcut]
URL=$siteUrl
"@ | Set-Content -LiteralPath $shortcutPath -Encoding ASCII

Write-Host ""
Write-Host "Windows now resolves $siteName to $ServerIp."
Write-Host "Caddy's public CA is trusted by this computer."
Write-Host "Desktop shortcut created: $shortcutPath"
Write-Host "Certificate SHA-256: $actualFingerprint"
Write-Host "Close and reopen any browser that was already running, then open $siteUrl"
Read-Host "Press Enter to close"
