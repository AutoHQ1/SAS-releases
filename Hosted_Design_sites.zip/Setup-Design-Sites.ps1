[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ServerIp,

    [string]$CertificateSha256 = ""
)

$ErrorActionPreference = "Stop"
$siteNames = @(
    "sas.apps",
    "sas-vsc.auto",
    "photocraft.sas.auto",
    "vectorcraft.sas.auto",
    "designcraft.sas.auto"
)
$certificateHost = "sas-vsc.auto"

$parsedAddress = $null
if (-not [System.Net.IPAddress]::TryParse($ServerIp, [ref]$parsedAddress) -or
    $parsedAddress.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
    throw "ServerIp must be an IPv4 address, such as 192.168.68.75."
}
$ServerIp = $parsedAddress.ToString()

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
$isAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdministrator) {
    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`"",
        "-ServerIp", $ServerIp
    )
    if ($CertificateSha256) {
        $arguments += @("-CertificateSha256", $CertificateSha256)
    }
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $arguments
    exit
}

$hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$backupPath = "$hostsPath.design-sites.backup"
Copy-Item -LiteralPath $hostsPath -Destination $backupPath -Force

$updatedLines = [System.Collections.Generic.List[string]]::new()
foreach ($line in @(Get-Content -LiteralPath $hostsPath)) {
    $hostPart = ($line -split "#", 2)[0]
    $fields = @($hostPart -split "\s+" | Where-Object { $_ })
    $matchesSite = $false
    foreach ($siteName in $siteNames) {
        if ($fields -contains $siteName) {
            $matchesSite = $true
            break
        }
    }
    if (-not $matchesSite) {
        $updatedLines.Add($line)
    }
}
foreach ($siteName in $siteNames) {
    $updatedLines.Add("$ServerIp`t$siteName")
}
Set-Content -LiteralPath $hostsPath -Value $updatedLines -Encoding ASCII
Clear-DnsClientCache

$temporaryCertificate = Join-Path ([System.IO.Path]::GetTempPath()) "design-sites-caddy-root.crt"
try {
    & curl.exe --fail --silent --show-error --insecure `
        --resolve "${certificateHost}:443:$ServerIp" `
        "https://$certificateHost/caddy-local-root.crt" `
        --output $temporaryCertificate
    if ($LASTEXITCODE -ne 0) {
        throw "Could not download Caddy's public CA certificate from $ServerIp."
    }

    $actualFingerprint = (Get-FileHash -LiteralPath $temporaryCertificate -Algorithm SHA256).Hash.ToUpperInvariant()
    $expectedFingerprint = ($CertificateSha256 -replace "[^0-9A-Fa-f]", "").ToUpperInvariant()
    if ($expectedFingerprint -and $actualFingerprint -ne $expectedFingerprint) {
        throw "Certificate fingerprint mismatch. Expected $expectedFingerprint but downloaded $actualFingerprint."
    }

    $certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($temporaryCertificate)
    try {
        if (-not $certificate.Subject -or $certificate.NotAfter -le (Get-Date)) {
            throw "The downloaded CA certificate is invalid or expired."
        }
    }
    finally {
        $certificate.Dispose()
    }

    Import-Certificate -FilePath $temporaryCertificate -CertStoreLocation "Cert:\LocalMachine\Root" | Out-Null
}
finally {
    Remove-Item -LiteralPath $temporaryCertificate -Force -ErrorAction SilentlyContinue
}

$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktopPath "SAS Apps.url"
@"
[InternetShortcut]
URL=https://sas.apps/
"@ | Set-Content -LiteralPath $shortcutPath -Encoding ASCII

Write-Host ""
Write-Host "Windows now resolves these names to ${ServerIp}:"
foreach ($siteName in $siteNames) {
    Write-Host "  https://$siteName/"
}
Write-Host "Caddy's public CA is trusted by this computer."
Write-Host "A desktop shortcut was created for https://sas.apps/"
Write-Host "Certificate SHA-256: $actualFingerprint"
Write-Host "Close and reopen any browser that was already running."
Read-Host "Press Enter to close"
