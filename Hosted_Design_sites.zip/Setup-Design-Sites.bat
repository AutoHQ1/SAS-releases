@echo off
setlocal
set /p SERVER_IP=Enter the server IPv4 address: 
if "%SERVER_IP%"=="" (
  echo A server IP address is required.
  pause
  exit /b 1
)
set /p CERT_SHA256=Enter the CA SHA-256 printed by the server installer ^(optional^): 
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Design-Sites.ps1" -ServerIp "%SERVER_IP%" -CertificateSha256 "%CERT_SHA256%"
if errorlevel 1 pause
